package net.ufjnet.projetodepratica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BckendPpApplicationTests {

	@Test
	void contextLoads() {
	}

}
